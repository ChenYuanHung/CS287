﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem2
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int Index = 0; Index < 2; Index++)
            {
                Product ProductN = new Product();
            
                try
                {
                    Console.Write("Please enter your product ID: ");
                    ProductN.Id = int.Parse(Console.ReadLine());
                }

                catch
                {
                    Console.WriteLine("Product ID Error!!");
                    return;
                }
                Console.Write("Please enter your product name: ");
                ProductN.Name = Console.ReadLine();

                try
                {
                    Console.Write("Please enter your product price: ");
                    ProductN.Price = int.Parse(Console.ReadLine());
                }

                catch
                {
                    Console.WriteLine("Product Price Error!!");
                    return;
                }
                Console.Write("Please enter your product category: ");
                ProductN.Categories = Console.ReadLine();
                Console.WriteLine("");
                Console.WriteLine("Your created product is: {0}", ProductN.Name );
                Console.WriteLine("The following are the details:");
                Console.WriteLine("Product ID: {0}", ProductN.Id);
                Console.WriteLine("Product Price: {0}", ProductN.Price);
                Console.WriteLine("Product Catogory: {0}", ProductN.Categories);
                Console.WriteLine("");
            }
        }
    }
}

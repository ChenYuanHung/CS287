﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int PokeIndex = 0; PokeIndex < 2; PokeIndex++)
            {
                Pokemon Pokemon1 = new Pokemon();
                try
                {
                    Console.Write("Please enter National No: ");
                    Pokemon1.NationalNo = int.Parse(Console.ReadLine());
                }

                catch
                {
                    Console.WriteLine("National No Error!!");
                    return ;
                }

                Console.Write("Please enter your Pokemon Name: ");
                Pokemon1.Name = Console.ReadLine();
                Console.Write("Please enter your Pokemon Type: ");
                Pokemon1.Type = Console.ReadLine();
                try
                {
                    Console.Write("Please enter Height: ");
                    Pokemon1.Height = float.Parse(Console.ReadLine());
                }

                catch
                {
                    Console.WriteLine("Height Error!!");
                    return;
                }
                try
                {
                    Console.Write("Please enter Weight: ");
                    Pokemon1.Weight = float.Parse(Console.ReadLine());
                }

                catch
                {
                    Console.WriteLine("Weight Error!!");
                    return;
                }
                Console.Write("Please enter your Pokemon Abilities: ");
                Pokemon1.Abilities = Console.ReadLine();
                try
                {
                    Console.Write("Please enter Local No: ");
                    Pokemon1.LocalNo = int.Parse(Console.ReadLine());
                }

                catch
                {
                    Console.WriteLine("Local No Error!!!");
                    return;
                }
                Console.Write("Please enter your Pokemon's Japanese name: ");
                Pokemon1.Japanese = Console.ReadLine();

                Console.WriteLine("");
                
                Console.WriteLine("The data of your Pokemon {0} is: ", PokeIndex+1);
                Console.WriteLine("National No: {0}", Pokemon1.NationalNo);
                Console.WriteLine("Type: {0}", Pokemon1.Type);
                Console.WriteLine("Species: {0}", Pokemon1.Species);
                Console.WriteLine("Height: {0}m", Pokemon1.Height);
                Console.WriteLine("Weight: {0}kg", Pokemon1.Weight);
                Console.WriteLine("Abilities: {0}", Pokemon1.Abilities);
                Console.WriteLine("Local No: {0}", Pokemon1.LocalNo);
                Console.WriteLine("Japanese: {0}", Pokemon1.Japanese);

                Console.WriteLine("");
            }
            
            

        }
    }
}

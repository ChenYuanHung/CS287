﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Problem1  
{
    public class Pokemon
    {
        public int NationalNo;
        public String Name;
        public String Type;
        public String Species;
        public float Height;
        public float Weight;
        public String Abilities;
        public int LocalNo;
        public String Japanese;
    }
}

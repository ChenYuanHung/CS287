﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("請輸入National No: ");
            String nationalNo = Console.ReadLine();
            Console.Write("請輸入Type: ");
            String Type = Console.ReadLine();
            Console.Write("請輸入Species: ");
            String Species = Console.ReadLine();
            Console.Write("請輸入Height: ");
            String Height = Console.ReadLine();
            Console.Write("請輸入Weight: ");
            String Weight = Console.ReadLine();
            Console.Write("請輸入Abilities: ");
            String Abilities = Console.ReadLine();
            Console.Write("請輸入Local No: ");
            String LocalNo = Console.ReadLine();
            Console.Write("請輸入Japanese: ");
            String Japanese = Console.ReadLine();
            Console.WriteLine("");
            Console.WriteLine("您輸入的資料如下：");
            Console.WriteLine("National No: {0}", nationalNo);
            Console.WriteLine("Type: {0}", Type);
            Console.WriteLine("Species: {0}", Species);
            Console.WriteLine("Height: {0}", Height);
            Console.WriteLine("Weight: {0}", Weight);
            Console.WriteLine("Abilities: {0}", Abilities);
            Console.WriteLine("Local No: {0}", LocalNo);
            Console.WriteLine("Japanese: {0}", Japanese);
        }
    }
}
